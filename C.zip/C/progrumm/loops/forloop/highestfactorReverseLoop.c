// #include<stdio.h>
// int main(){

//   int a;
//   printf("Enter a value:");
//   scanf("%d",&a);
//   //int hf=1;
//   for(int i=a/2; i>=1; i--) {
//     if(a%i==0){//hf =i; 
//       printf("The highest factor is %d",i);
//                break;}
//   }//printf("The highest factor is %d",hf);
//   return 0;
// }