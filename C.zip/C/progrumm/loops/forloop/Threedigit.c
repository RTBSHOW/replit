//#include<stdio.h>
// int main(){
//   int x;
//   printf("Enter a value");
//   scanf("%d",&x);
//   if(x>=100 && x<=999) {printf("The number is a three digit number");}
//                     else printf("The number is not a three digit nimber");
                      
//   return 0;
// }