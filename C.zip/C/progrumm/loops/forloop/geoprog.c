// #include<stdio.h>
// int main(){
//   int a;
//   printf("Enter the progression:");
//   scanf("%d",&a);
//   int c=1;
//   for (int i=1; i<=a; i=i+1){
//     printf("%d\n",c);
//     c=c*5;
//   }
// }