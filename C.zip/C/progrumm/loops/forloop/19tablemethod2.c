// #include<stdio.h>
// int main(){
//   int a;
//   printf("Enter a value:");
//   scanf("%d",&a);
//   for(int i=a ; i<=a*10; i=i+1){
//     if(i%a==0){
//       printf("%d\n",i);
//     }
//   }
// }