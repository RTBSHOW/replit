// #include<stdio.h>
// int main(){
//   int a;
//   printf("Enter a value:");
//   scanf("%d",&a);
//   for(int i=a ; i<=a*10; i=i+a){
//     printf("%d\n",i);
//   }
// }