// #include<stdio.h>
// int main(){
//   int a;
//   printf("Enter a value:");
//   scanf("%d",&a);
//   for (int i=1; i<=2*a-1; i=i+2){
//     printf("%d\n",i);
//   }
// }