// #include<stdio.h>
// int main(){
//   int a;
//   printf("Enter a value:");
//   scanf("%d",&a);
//   for (int i=1; i<=a; i++){
//     printf("Hello World\n");
//   }
//   return 0;
// }