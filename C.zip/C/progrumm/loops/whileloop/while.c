// #include<stdio.h>
// int main(){ 
//   int a;
//   printf("Enter a number: ");
//   scanf("%d",&a);

//   int i=2;
//   while (i<=a){
//     if(a%i==0){
//     printf("%d is a composite number\n",a);}
//     break;
//     i++;

//   }
//   return 0;
// }