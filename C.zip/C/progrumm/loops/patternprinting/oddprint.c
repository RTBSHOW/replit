// #include <stdio.h>
// int main()
// {
//   int s;
//   printf ("Enter the number of sides: ");
//   scanf ("%d",&s);
//   for(int i=1; i<=s*2;i=i+2){
//     for(int j=1; j<=s*2; j=j+2){
//       printf("%d ",j);
//     }printf(" \n");
//   }
//   return 0;
// }