// #include<stdio.h>
// int main(){
//   int s;
//   printf("Enter numbetr of rows: ");
//   scanf("%d",&s);
//   for(int i=1; i<=s; i++){
//     for(int j=s; j>=i; j--){
//       printf("%d ",i);
//     }
//     printf("\n");
//   }
//   return 0;
// }