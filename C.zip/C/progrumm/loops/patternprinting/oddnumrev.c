// #include<stdio.h>
// int main()  
// {
//     int r;
//   printf("Enter the number of rows: ");
//   scanf("%d",&r);
//  for(int i=1; i<=r*2;i=i+2) {
//     for(int j=1; j<=i; j=j+2){
//       printf("%d ",j);
//     } printf(" \n");
//  }
//   return 0;
// }