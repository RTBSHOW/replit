// #include<stdio.h>
// int main(){
// int m;
//   printf("Enter the number of lines: ");
//   scanf("%d",&m);
//   int n;
//   printf("Enter the number of stars: ");
//   scanf("%d",&n);
//   // nested loop
// for(int i=1; i<=m; i++){
//   for(int j=1; j<=n; j++){
//     printf("*");
//   }
//   printf("\n");
// }
//   return 0;
// }