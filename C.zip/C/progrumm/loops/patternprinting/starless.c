// #include<stdio.h>
// int main(){
//   int s;
// printf("Enter the row of the triangle: ");
//   scanf("%d",&s);
//   for(int i=1; i<=i; i++){
//     for( int j=1; j<=i; j++){ //i creates the difference between the number of stars and the number of spaces
      
//       printf("* ");
//     }
//     printf("\n");
//   }
//   return 0;

// }