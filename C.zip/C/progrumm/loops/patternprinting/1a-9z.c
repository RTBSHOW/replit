// #include<stdio.h>
// int main()
// {
//   int a;
//   printf("Enter the number of rows: ");
//   scanf("%d",&a);
//   for(int i=1; i<=a; i++)
//   {
//     for(int j=1; j<=i; j++){
//       if(i%2==0) printf("%c ",j+64);
//       else printf("%d ",j);
//     }
//       printf(" \n");
//     }
//   } 
