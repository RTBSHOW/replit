// #include<stdio.h>
// int main()
// {
//   int s;
//   printf("Enter the row : ");
//   scanf("%d",&s);
//   for(int i=1; i<=s; i++){
//     for(int j=s; j>=i; j--){
//       printf("%c ",i+64);
//     }
//     printf("\n");
//   }
//   return 0;
// }