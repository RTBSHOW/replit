// #include<stdio.h>
// int main(){
//   int r;
//   printf("Enter number of rows");
//   scanf("%d",&r);
//   for(int i=1; i<=r; i++){
//     for(int j=1; j<=i; j++){
//       if(i%2==0){printf("%d",i);}
//       else printf("%c",i+64);
      
//     }
//     printf("\n");
//   }
// }