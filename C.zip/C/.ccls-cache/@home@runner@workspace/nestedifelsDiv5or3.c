// #include<stdio.h>
// int main(){
//   int x;
//   printf("Enter a value:");
//   scanf("%d",&x);
//   if(x%5==0){ if(x%3==0) printf("The number is divisible by 3 and 5");
//             else printf("The number is not divisible by 3 and 5");}
  
//   else {printf("Not divisible by 5 and 3");}
//   return 0;
// }