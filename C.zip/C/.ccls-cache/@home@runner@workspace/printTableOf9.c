// #include <stdio.h>
// int main (){
//   for(int i=19; i<=190; i=i+19){
//     printf("%d\n",i);
//   }
//   return 0;
// }
