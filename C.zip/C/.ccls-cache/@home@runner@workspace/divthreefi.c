// #include<stdio.h>
// int main(){
//   int x;
//   printf("Enter a value");
//   scanf("%d",&x);
//   if(x%3==0 && x%5==0) {printf("The number is divisible by 3 and 5");}
//   else printf("The number is not divisible by 3 and 5");  
//   return 0;
// }