// #include <stdio.h>
// int main(){
//   int a;
//   printf("Enter a Year:");
//   scanf("%d",&a);
//   (a%400==0 ||(a%4==0 && a%100!=0)) ? printf("The Year is a leap year:") : printf("The Year is not a leap year");
//   return 0;
    
//     }