// #include <stdio.h>
// int main(){
//   char ch;
//   printf("Enter a operator");
//   scanf("%c",&ch);
//   int a;
//   printf("Enter a value:");
//   scanf("%d",&a);
//   int b;
//   printf("Enter a value:");
//   scanf("%d",&b);
//   switch(ch){
//     case '+': printf("The sum is:%d",a+b);
//     break;
//     case '-' : printf("The difference is:%d",a-b);
//     break;  
//     case '*' : printf("The product is:%d",a*b);
//     break;
//   case '/' : printf("The quotient is:%d",a/b);
//     break;
//   case '%' : printf("The remainder is:%d",a%b);
//     break;
//     default : printf("Invalid operator");
//   }
//     return 0;
  
// }

