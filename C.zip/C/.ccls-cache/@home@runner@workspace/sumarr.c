// #include <stdio.h>
// void GetArrayfromUser(int arr[],int n)
// {
//  for (int j=0;j<n; j++){
//    scanf("%d",&arr[j]);
//  }
  
// }

// int main()
// {
//   int arr[5];
  
//   int n=5;
//   int j;
//   printf("Enter numbers to sum:");
  
//   GetArrayfromUser(arr,n);
//   scanf("%d",&arr[j]);
//   int sum=0;
//   for (int i=0; i<5; i++)
//     {
//       sum = sum+arr[i];
//     }
//   printf("The sum of array is %d:",sum);
//   return 0;
  
// }