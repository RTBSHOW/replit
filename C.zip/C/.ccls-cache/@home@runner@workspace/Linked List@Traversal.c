// #include <stdio.h>
// #include <stdlib.h>
// struct Node {
//     int data;

//     struct Node *next;
// };

// void traversal(struct Node*pointer)
// {
//     while(pointer!= NULL)
//     {
//         printf("DATA:%d\n",pointer-> data);
//         pointer= pointer-> next;
//     }
// }

// int main() {
//     //Define the Struct Node pointer name.
//     struct Node *head;
//     struct Node *second;
//     struct Node *third;
//     struct Node *forth;
//     //Provide storage from heap.
//     head= (struct Node*) malloc(sizeof(struct Node));
//     second= (struct Node*)malloc(sizeof(struct Node));
//     third=(struct Node*)malloc(sizeof(struct Node));
//     forth=(struct Node*)malloc(sizeof(struct Node));
//         //Provideing value and pointer to the named struct data type.
//     head-> data=12;
//     head-> next= second;
//     second->data=32;
//     second-> next= third;
//     third-> data= 43;
//     third-> next= forth;
//     forth-> data= 54;
//     forth-> next= NULL;

//     //traversal of linked list to print.
//     traversal(head);
   
//     return 0;
// }