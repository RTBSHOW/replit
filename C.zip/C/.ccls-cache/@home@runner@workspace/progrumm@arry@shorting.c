// #include<stdio.h>
// #include<stdlib.h>
// void display(int arr[], int n)
// {
//   for(int i=0; i<n; i++)
//   {
//     printf("%d\n",arr[i]);
//   }
// }
// void shorting(int arr[], int n)
// {
//   int found=0;
//   int temp;
//   for(int i=0; i<=n; i++)
//     {
//       if(arr[i]>arr[i+1])
//       {
//       arr[i]=temp;
//         temp= arr[i+1];
       
//       }
//     }
// }
// int main(){
//   int arr[15]={12,4,5,19,221,54,42,21};
//   int n=8;
//   shorting(arr,n);
//   printf("Shorted arrays are\n");
//   display(arr,n);
  
  
// }