// #include <stdio.h>
// #include<stdlib.h>
// int main(){

//   FILE* ptr= fopen("text.txt","r");
//   if(ptr == NULL) {
//     printf("Error: Could not open file\n");
//     return 1;
//   }
  
//   char str[100];
//   while(fgets(str,100,ptr)!= NULL)
//     printf("%s",str);
  
//   fclose(ptr);
//   return 0;
// }
