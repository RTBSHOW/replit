// #include <stdio.h>
// int main(){
//   int a;
//   printf("Enter a value:");
//   scanf("%d",&a);
//   int rev=0, orginal=a, rem;
//   while(a!=0){
//     rem=a%10;
//     rev=rev*10+rem;
//     a=a/10;
//     if(orginal==rev){
//       printf("The number is palindrome");
//       break;
//     }
//     else{
//       printf("The number is not palindrome");
//     }
//   }
//   return 0;
// }