// #include<stdio.h>
// int main(){
//   int a;
//   printf("Enter a value:");
//   scanf("%d",&a);
//   if(a%5 || a%3) {printf("The number is divisible by 3 or 5");}
//   else printf("The number is not divisiable by 3 or 5");
//   return 0;
// }