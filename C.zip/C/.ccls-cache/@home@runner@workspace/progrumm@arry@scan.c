// #include<stdio.h>
// int main(){
//   int arr[12];
//   for(int i=0; i<=11; i++){
//     printf("Enter the value of %d index: ",i);
//     scanf("%d",&arr[i]);  
//   }
//   if(arr[i]%2==0){
//     printf("The value of %d index is %d",arr[i]);
//   }
  
// }