// #include<stdio.h>
// int main()
// {
//   int n;
//   printf("Enter a value:");
//   scanf("%d",&n);
//   for(int i=2;i<=n/2;i++)
//   {
//     if(i%1==0 && n%i==0)
//     {printf("prime number s %d\n",i);
    
//     }
//   }
// return 0;

// }