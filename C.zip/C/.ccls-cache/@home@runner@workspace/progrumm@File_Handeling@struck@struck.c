// #include<stdio.h>
// struct prakash{

// };

// int main(){

//   return 0;
// }