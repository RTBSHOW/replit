// #include <stdio.h>

// int main() {
//   int a=21;
//   int* ptr=&a;

//   printf("%d", *ptr);

  
//   return 0;
// }