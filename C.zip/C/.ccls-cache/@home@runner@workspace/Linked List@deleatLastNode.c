// #include<stdio.h>
// #include<stdlib.h>

// // Creat struct Node
// struct Node
// {
// int data;
// struct Node *next;

// };
// void printlist(struct Node *head)
// {
//   while(head!=NULL)
//     {
//       printf("list: %d \n",head ->data);
//       head =head->next;
//     }
// }
// // deleat first node
// struct Node *DeleatLast(struct Node *head)
// {
//   struct Node *ptr;
//   ptr= head;
//   struct Node *p;
//   p ->next= ptr;

//   while(ptr->next!=NULL)
//     {
//       ptr= ptr->next;
      
//     }
  
//   p ->next=NULL;
//   free(ptr);
  
  
 
//   return head;
// }

// int main()
// {
//   // Creat struct node data type name
//   struct Node *head =(struct Node*)malloc(sizeof(struct Node));
//   struct Node *second=(struct Node*)malloc(sizeof(struct Node));
//   struct Node *third=(struct Node*)malloc(sizeof(struct Node));
//   struct Node *forth=(struct Node*)malloc(sizeof(struct Node));
//   // value of every node
//   head -> data=43;
//   head ->next =second;
//   second -> data=121;
//   second ->next =third;
//   third -> data=67;
//   third ->next =forth;
//   forth ->data= 12;
//   forth ->next= NULL;


//   printlist(head);
//   head = DeleatLast(head);
//   printf("After Deleating List:\n");
//   printlist(head);

//   return 0;

// }