// #include <stdio.h>
// int main(){
//   int a,b,c;
//   printf("Enter three Positive numbrt:");
//   scanf("%d %d %d", &a, &b, &c);
// if(a>b){
//   if(a>c) printf("The largest Value is:%d",a); 
//   else printf( "The largest Value is:%d",c);
// } 
// else{
//   if(b>c) printf("The largest Value is:%d",b);
//   else printf("The largest Value is:%d",c);
  
// } 

//   return 0;



//   }