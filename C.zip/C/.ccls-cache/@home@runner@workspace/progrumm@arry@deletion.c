// #include<stdio.h>
// #include<stdlib.h>
// void display(int arr[], int size){
//   for (int i=0; i< size; i++){
//   printf("%d\n", arr[i]);
//   }

// }
// void insert(int arr[], int size ,int capacity,int index,int element){
 
  
//   for(int i=index; i<size-1; i++){
//     arr[i]=arr[i+1];
//   }
//  arr[index]= arr[index+1];
// }
// int main(){
//   int arr[100]={34, 45, 55, 88, 98, 212};
//   int size=6; int capacity=100,index, element;
 
//   printf("enter index to deleat:\n");
//   scanf("%d",&index);
//   insert(arr,size,capacity,index,element);

// printf("Enter nuber of elements to display:");  
// scanf("%d",&size);
//   display( arr,size);
// }