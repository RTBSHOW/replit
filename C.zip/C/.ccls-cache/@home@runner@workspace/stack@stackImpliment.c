// #include<stdio.h>
// #include<stdlib.h>
// struct Stack
// {
// int Capacity;
// int top;
// int *arr;

// };
// int StackEmpty(struct Stack *ptr)
// {
//   if(ptr->top==-1)
//   {
//     printf("The Stack is Empty.\n");
//   }
  
//   else {printf("The stack is not empty\n");
    
//   }
//   return 1;
// }
// int StackFull(struct Stack *ptr)
// {
//   if(ptr->top==ptr->Capacity-1)
//   {
//     printf("The Stack is full\n");
//   }
//   else {
//     printf("stack is not full\n");
//   }
//   return 0;
// }
// int main()
// {
//   // struct Stack s;
//   // s.Capacity=60;
//   // s.top=-1;
//   // s.arr=(int*)malloc(s.Capacity * sizeof(int));
//   // or
//   struct Stack *s;
//   s->Capacity=6;
//   s->top=-1;
//   s->arr=(int*)malloc(s->Capacity * sizeof(int));

//   s->arr[0]=23;
//   s->top++;
//   StackEmpty(s);
//   StackFull(s);

  
//   return 0;
// }