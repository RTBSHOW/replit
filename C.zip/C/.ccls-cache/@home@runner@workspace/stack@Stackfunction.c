#include<stdio.h>
#include<stdlib.h>
struct Stack
{
int Capacity;
int top;
int *arr;

};

int StackEmpty(struct Stack *ptr)
{
  if(ptr->top==-1)
  {
    return 1;
  }

  else
  {
    return 0;
  }

}

int StackFull(struct Stack *ptr)
{
  if(ptr->top==ptr->Capacity-1)
  {
    return 1;
  }
  else 
  {
    return 0;
  }

}

void push(struct Stack *ptr, int value)
{
  if(StackFull(ptr))
  {
    printf("%d Can not be pushed",value);
  } 
  else
  {
    ptr->top++;
    ptr->arr[ptr->top]=value;

  }
}
  int pop(struct Stack *ptr)
  {
      if(StackEmpty(ptr))
      {
          printf("Cannot be popped: Stack Underflow\n");
          return -1; // error code
      }
      else
      {
          int val = ptr->arr[ptr->top];  // save value
          ptr->top--;                    // move top down
          return val;                    // return popped value
      }
  }

int main()
{
  // struct Stack s;
  // s.Capacity=60;
  // s.top=-1;
  // s.arr=(int*)malloc(s.Capacity * sizeof(int));
  // or
  struct Stack *s= (struct Stack*)malloc(sizeof(struct Stack));
  s->Capacity=6;
  s->top=-1;
  s->arr=(int*)malloc(s->Capacity * sizeof(int));
  int v;
  for (int i = 0; i < s->Capacity; i++)
  {
      printf("Enter values to push:\n");
      scanf("%d", &v);
      push(s, v);
      printf("%d has been pushed\n", v);
  }
  
  if(StackFull(s))
    {
        printf("Stack is full, can't push more\n");
    }

    while(!StackEmpty(s))
    {
        v = pop(s);
        printf("%d has been popped\n", v);
    }

    printf("Stack is empty: %d\n", StackEmpty(s));



  return 0;
}