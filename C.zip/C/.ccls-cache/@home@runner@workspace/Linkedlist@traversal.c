#include <stdio.h>
#include<stdlib.h>
struct  Node 
{
int data;


};
int main()
{
  return 0;
}