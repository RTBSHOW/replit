// #include <stdio.h>
// int main(){
//   int a;
//   printf("Enter a Number:");
//   scanf("%d", &a);
// if(a%15!=0 && (a%5==0 || a%3==0 )) {printf("The number is divisible by 3 or 5 but not by 15");}
//   if(a%15==0) {printf("The number is divisible by 15");}

//   return 0;



//   }