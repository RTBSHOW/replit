// #include <stdio.h>
// int main(){
//   int a;
//   printf("Enter a Number:");
//   scanf("%d", &a);
// if(a%15!=0){ printf("Valid");
//   if(a%5==0) {printf("Valid");
//              }
//   if(a%3==0) {printf("Valid");
//              }
//    else printf("Invalid");
//            }
//   else printf("invalid");

//   return 0;



//   }