// #include <stdio.h>
// int main(){
//   int x,y;
//   printf("Enter two Points:");
//   scanf("%d %d", &x, &y);
// if(x==0 && y==0) printf("The point lies at the origin");
//   else if(x>0 && y>0) printf("The point lies in the first quadrant");
//   else if(x<0 && y>0) printf("The point lies in the second quadrant");
//   else if(x<0 && y<0) printf("The point lies in the third quadrant");
//   else if(x>0 && y<0) printf("The point lies in the fourth quadrant");
//   else if(x>0 || x<0 && y==0) printf("The point lies on the x-axis");
//   else printf("The point lies on the y-axis");
  
//   return 0;



//   }